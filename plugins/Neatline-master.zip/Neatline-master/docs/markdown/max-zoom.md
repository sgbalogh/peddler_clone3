## Max Zoom

The zoom level "below" which the record will be visible, with zooming "out" being "lower" (eg, focusing on Europe is "lower" than focusing on Spain). For example, if the record has a point on the map and "Max Zoom" is `10`, then the point will be invisible when the map at zoom level `11`, and will become visible as soon as the map zooms to `10`.

Like with "Min Zoom," click the "Use Current" button next to the field title to automatically insert the current zoom level into the input.
