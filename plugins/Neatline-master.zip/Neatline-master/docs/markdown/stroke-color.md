## Stroke Color

The color of the lines that run around the edges of shapes on the map.

To change the color, click on the input and use the color-picker widget to select a new color. As you edit the value, the record's geometry on the map will automatically update to preview the new color.
