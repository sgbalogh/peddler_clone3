## WMS Address

The location of a web-accessible Web Map Service server like Geoserver. This field has to link directly to the WMS API endpoint on the server, such as:

`http://libsvr35.lib.virginia.edu/geoserver/hotchkiss/wms`
