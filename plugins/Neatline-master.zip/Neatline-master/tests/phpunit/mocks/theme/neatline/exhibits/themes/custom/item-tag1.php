custom-<?php echo get_current_record('item')->id; ?>-tag1
